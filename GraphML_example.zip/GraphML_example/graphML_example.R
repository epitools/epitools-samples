# Example R script to read the GraphML files from the EpiTools plugins for ICY
# 
# The input files were generated using the GraphML export function of the
# CellExport plugin on the test graph included with the plugins.
#
# The example shows a simple query that finds the mean area of the 
# neighboring cells of cells that will divide during the time lapse
# 
# Author: Davide Heller <davide.heller@imls.uzh.ch>
# Date: 2015/05/11

##LOADING PROCEDURE

#load helper functions
source("graphML_helperFunctions.R")

#specify where the test_folder with the GraphML files is located
#in this example we will only use the first time point
test_folder <- 'test_graphML/'
test_graph <- paste(test_folder,"frame000.xml",sep="")
test_header <- paste(test_folder,"GraphML_attributeHeader.csv",sep="")

#read a the graph and the connected attributes from a graphML frame
g <- read_graphML(graph_file = test_graph)
cell <- read_csv_tag(g = g,header_file = test_header)

##GRAPH ANALYSIS

#1. Get all cells that will divide during the time lapse
dividing_cells <- which(cell$has_division)

#2. Loop over the dividing cells
for(dividing_cell in dividing_cells){
  
  #3. Get the neighboring cells of the dividing cell
  neighboring_cells <- neighbors(g, dividing_cell)
  
  #4. Get the areas of the neighboring cell
  neighboring_cell_areas <- cell$area[neighboring_cells]
  
  #5. Compute the area mean
  mean_neighbor_area <- mean(neighboring_cell_areas)
  
  #6. Print the results
  print(paste("The mean neighbor area of",cell$id[dividing_cell],'is',mean_neighbor_area))
  
}
    