# Example R script to read the GraphML files from the EpiTools plugins for ICY
# 
# Helper function to read the GraphML files with a special header
# 
# Author: Davide Heller <davide.heller@imls.uzh.ch>
# Date: 2015/05/11

require(igraph)

#igraph function to read the graphML file
read_graphML <- function(graph_file){
  read.graph(file=test_graph, format="graphml")
}

#function to read the csv string in the vertex attributes
read_csv_tag <- function(g,header_file){
  
  #reading the header containing names and classes of the attributes
  csv_header <- read.csv(header_file)
  csv_names <- colnames(csv_header)
  csv_classes <- as.character(sapply(csv_header,as.character))
  
  #resulting table containing all attributes
  cell <- data.frame()
  
  #loop over all cells in the graph and extract their attributes
  for(v in V(g)){
    tag <- get.vertex.attribute(g,"Vertex Label",v)
    values <- read.csv(text=tag, header=F, 
                       col.names=csv_names, 
                       colClasses=csv_classes)
    cell <- rbind(cell,values)
  }
  
  return(cell)
}